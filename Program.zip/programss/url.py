from django.urls import path
from .views import login, create, first, index

urlpatterns = [
    path('', first, name='first'),
    path('login/', login, name='login'),
    path('creat/<int:id>', create, name='creat'),
    path('index/<int:id>', index, name='index'),
]

app_name = 'meva'
