from django.db import models
from django.urls import reverse


class login(models.Model):
    username = models.CharField(max_length=50)
    email = models.EmailField()
    password = models.CharField(max_length=30)

    def __str__(self):
        return self.username


class nom(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
         return self.name


class tur(models.Model):
    turi = {'olma': 'olma', 'gilos': 'gilos', 'olcha': 'olcha', 'qulupnay': 'qulupnay'}
    size = models.CharField(max_length=50, choices=turi.items())

    def __unicode__(self):
        return unicode(self.size)


class meva(models.Model):
    turi = {'olma': 'olma', 'gilos': 'gilos', 'olcha': 'olcha', 'qulupnay': 'qulupnay'}
    adress = models.CharField(max_length=300)
    # meva_turi = models.ForeignKey('tur', str, related_name='meva_turi')
    meva_type = models.CharField(max_length=50, choices=turi.items())
    meva_phase = models.CharField(max_length=100)
    information = models.TextField(blank=True)
    create = models.DateTimeField(auto_now_add=True)
    update = models.DateTimeField(auto_now=True)
    tel = models.CharField(max_length=20)

    def __str__(self):
        return f'{self.adress}: {self.meva_type}'

    def urldb(self):
        return reverse('meva:index', kwargs={'id': self.pk})