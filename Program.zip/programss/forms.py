from django import forms
import programss.models as meva

class Login(forms.ModelForm):
    class Meta:
        model = meva.login
        fields = '__all__'

class Tur(forms.ModelForm):
    class Meta:
        model = meva.meva
        fields = '__all__'
