from django.apps import AppConfig


class ProgramssConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'programss'
