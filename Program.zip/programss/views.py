from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import *
import programss.models as db

dbase = {'login': db.login.objects.all(),
         'meva': db.meva.objects.all()}


def first(request):
    return render(request, 'meva/base.html', {'bool': True})


def login(request):
    if request.method == 'POST':
        z = Login(request.POST)
        if z.is_valid():
            if 'password_r' in request._post:
                try:
                    dbase['login'].get(email=request._post['email'])
                    messages.error(request, 'An email with this name is available, change the email')
                    return render(request, 'meva/login.html', {'bool': True})
                except Exception:
                    if request.POST['password_r'] == request.POST['password']:
                        z.save()
                        dbase['login'] = db.login.objects.all()
                        return render(request, 'meva/base.html', {'boolen': True})
                    else:
                        messages.success(request, z.cleaned_data['email'])
                        messages.error(request, 'There is an error in the password, correct them')
                        return render(request, 'meva/login.html', {'bool': True})
            else:
                try:
                    z = (dbase['login']).get(email=request._post['email'])
                    if z.password != request.POST['password'] or z.username != request.POST['username']:
                        messages.error(request, 'There is an error in the username or password, please correct them')
                        return render(request, 'meva/login.html')
                    return render(request, 'meva/base.html', {'boolen': True})
                except Exception:
                    messages.error(request, 'No email with this name was found. Please try again')
                    return render(request, 'meva/login.html')
        else:
            messages.error(request, 'There is an error in the data. Fix it')
            return render(request, 'meva/login.html')
    else:
        if 'q' in request.GET:
            return render(request, 'meva/login.html', {'bool': True})
        else:
            return render(request, 'meva/login.html', {'bool': False})


def create(request, id):
    if int(id) > 0 and request.method == 'GET':
        malumot = dbase['meva'].filter(pk=int(id))
        if(zet := Tur(malumot.values()[0])).is_valid():
            return render(request, 'meva/create.html', {'post': zet, 'id': int(id)})
    elif int(id) > 0 and request.method == 'POST':
        if (z := Tur(request.POST)).is_valid():
            dbase['meva'].filter(pk=int(id)).delete()
            z.save()
            dbase['meva'] = db.meva.objects.all()
            return redirect('/index/0')
    if request.method == 'POST':
        if (z := Tur(request.POST)).is_valid():
            z.save()
            dbase['meva'] = db.meva.objects.all()
            return redirect('/index/0')
    return render(request, 'meva/create.html', {'post': Tur(), 'id': 0})


def index(request, id):
    if int(id) > 0:
        try:
            zet = dbase['meva'].filter(pk=int(id))
            zet = zet.values('id', 'adress', 'meva_type','meva_phase', 'information', 'create', 'tel')[0]
            return render(request, 'meva/index.html', {'post': zet, 'zet': 1})
        except Exception as e:
            messages.error(request, f'{e}')
    return render(request,'meva/index.html', {'post': dbase['meva'], 'zets': 1})
